var searchData=
[
  ['setcolor',['setColor',['../classRGBTools.html#abae1532b9eeb14cc87e4dc76ee47dce1',1,'RGBTools::setColor(uint8_t r, uint8_t g, uint8_t b)'],['../classRGBTools.html#adc01431871aa62406695050f2df94220',1,'RGBTools::setColor(uint32_t)']]]
];
