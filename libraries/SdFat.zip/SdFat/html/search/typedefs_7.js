var searchData=
[
  ['spidefault_5ft',['SpiDefault_t',['../_sd_spi_8h.html#ad2c24f6ae166193062e50d14c5342b95',1,'SdSpi.h']]],
  ['streamsize',['streamsize',['../classios__base.html#a82836e1d3cc603fba8f0b54d323a2dff',1,'ios_base']]]
];
