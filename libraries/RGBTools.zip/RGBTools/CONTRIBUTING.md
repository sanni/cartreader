## Running test cases

There are test cases in the subfolder `tests`. Please run them before making a pull request by exexuting `compare.sh`. Watch out for messages telling you there is a difference between actual and expected output.

However, these tests are not mandatory. Just talk to the author. They're currently not integrated in a CI build or anything.
