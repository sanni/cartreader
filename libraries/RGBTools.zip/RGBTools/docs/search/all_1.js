var searchData=
[
  ['rgbtools',['RGBTools',['../classRGBTools.html',1,'RGBTools'],['../classRGBTools.html#aa09407e8413a68bb0da98f1261bb660c',1,'RGBTools::RGBTools(uint8_t r, uint8_t g, uint8_t b)'],['../classRGBTools.html#af6bda3ba54b1c630e37e672bf994f20c',1,'RGBTools::RGBTools(uint8_t r, uint8_t g, uint8_t b, Mode mode)']]]
];
